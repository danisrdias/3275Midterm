package com.example.demo.controller;


import com.example.demo.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService service;

/*
    //public String getBooks(){return "hELLOW wORD";}
    @GetMapping
    public String getBook(){
        return service.getBooks();
    }*/



   @GetMapping
    public String getJokeString(){
        return service.getJokeString();
    }

/*

    @GetMapping
    public String getString(){
    return service.getUserByName();
    }*/

/*    @PostMapping()
    public Book postBook(@RequestBody Book book){
        return service.createBook(book);
    }*/


}

