
package com.example.demo.service;


import com.example.demo.entity.Jokes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;

@Service
public class BookService {

    @Autowired
    private Jokes jokes;

 /*   @Autowired
    private BookDAO bookDAO;

    //create the format that will be used in the controller
    public String getBooksString(){
        Collection<Book> books = bookDAO.getBooks();
        String strings = "";
        for (Book book:books) {
            strings += book.getTitle().toString();

        }
        bookDAO.deleteBook(books.size()-1);
        String oneMore = "One More";
        return strings + oneMore;
    }

    public String getUserByName(){
        List<Book> listOfBooks = bookDAO.findUserByName("Title One");
        String string ="";
        for(Book book : listOfBooks){
            string = book.getTitle() + " "+ book.getAuthor();
        }
        return string;
    }

    public Collection<Book> getBooks(){
        return bookDAO.getBooks();
    }*/
    public String getJokeString(){
        return jokes.getRandomJokes();
    }

}

